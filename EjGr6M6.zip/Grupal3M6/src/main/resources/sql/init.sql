-- Capacitaciones

-- Insert 1
INSERT INTO Capacitacion (rut_Cliente, dia, hora, lugar, duracion, cantidad_Asistentes)
VALUES ('123456789', '2023-08-11', '09:00', 'Sala A', '2 horas', '20');

-- Insert 2
INSERT INTO Capacitacion (rut_Cliente, dia, hora, lugar, duracion, cantidad_Asistentes)
VALUES ('987654321', '2023-08-12', '14:00', 'Sala B', '3 horas', '15');

-- Insert 3
INSERT INTO Capacitacion (rut_Cliente, dia, hora, lugar, duracion, cantidad_Asistentes)
VALUES ('543216789', '2023-08-13', '10:30', 'Sala C', '1.5 horas', '10');

-- Insert 4
INSERT INTO Capacitacion (rut_Cliente, dia, hora, lugar, duracion, cantidad_Asistentes)
VALUES ('987612345', '2023-08-14', '16:00', 'Sala D', '2.5 horas', '25');

-- Insert 5
INSERT INTO Capacitacion (rut_Cliente, dia, hora, lugar, duracion, cantidad_Asistentes)
VALUES ('654321987', '2023-08-15', '11:00', 'Sala E', '2 horas', '18');

-- Usuarios

--
Insert 1
INSERT INTO Usuario (nombre_Usuario, contrasena)
VALUES ('admin', 'admin123');

-- Inser 2

INSERT INTO Usuario (nombre_Usuario, contrasena)
VALUES ('patricio', 'patricio123');